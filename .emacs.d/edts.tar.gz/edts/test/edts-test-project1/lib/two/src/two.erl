-module(two).
-export([two_fun/0]).

two_fun() -> ok.

%%%_* Emacs ====================================================================
%%% Local Variables:
%%% erlang-indent-level: 2
%%% End:
