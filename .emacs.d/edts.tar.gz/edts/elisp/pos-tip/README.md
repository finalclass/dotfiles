pos-tip
=======

pos-tip.el from http://www.emacswiki.org/emacs/PosTip
